/*
 * main.c
 *
 *  Created on: Oct 27, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/06-SPI/SPI_Interface.h"
#include "util/delay.h"

int main(void){
	u8 word[] = "I am Micro 1";

	/* MISO OUTPUT */
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN4, DIO_u8OUTPUT); // spi SS
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN5, DIO_u8OUTPUT); //MOSI
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN7, DIO_u8OUTPUT); //SCK
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN6, DIO_u8INPUT); //MISO

	SPI_MasterInit();

	while(1){
		SPI_SendString(word);
		_delay_ms(10);
	}
}
