/*
 * GIE_Interface.h
 *
 *  Created on: Oct 25, 2023
 *      Author: hp
 */

#ifndef GIE_INTERFACE_H_
#define GIE_INTERFACE_H_

void GIE_EnableInterrupts(void);
void GIE_DisableInterrupts(void);


#endif /* 04_MCAL_04_GIE_GIE_INTERFACE_H_ */
