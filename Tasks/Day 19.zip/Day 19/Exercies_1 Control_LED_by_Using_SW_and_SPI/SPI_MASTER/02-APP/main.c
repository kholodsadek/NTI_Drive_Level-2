/*
 * main.c
 *
 *  Created on: Oct 27, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/06-SPI/SPI_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"
#include "../03-HAL/03-BUSH_BUTTON/BushButton_Interface.h"
#include "util/delay.h"

int main(void){
	u8 SW_Press;

	/* MISO OUTPUT */
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN4, DIO_u8OUTPUT); // spi SS
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN5, DIO_u8OUTPUT); //MOSI
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN7, DIO_u8OUTPUT); //SCK
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN6, DIO_u8INPUT); //MISO

	Button button;
	button.button_pin = DIO_U8PIN0;
	BushButton_voidInit(&button);

	SPI_MasterInit();

	while(1){
		SW_Press = BushButton_voidRead(&button);
		SPI_SendData(SW_Press);
		_delay_ms(10);
	}
}
