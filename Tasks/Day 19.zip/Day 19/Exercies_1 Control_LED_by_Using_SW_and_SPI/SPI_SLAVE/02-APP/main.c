/*
 * main.c
 *
 *  Created on: Oct 27, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/06-SPI/SPI_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"
#include "../03-HAL/03-BUSH_BUTTON/BushButton_Interface.h"
#include "util/delay.h"

int main(void){
	u8 receiveData;

	/* MISO OUTPUT */
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN4, DIO_u8INPUT); //spi ss
	DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN4, DIO_u8HIGH);
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN5, DIO_u8INPUT); //MOSI
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN7, DIO_u8INPUT); //SCK
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN6, DIO_u8OUTPUT); //MISO

	LED_voidInit(DIO_U8PIN0);

	SPI_SlaveInit();

	while(1){
		receiveData = SPI_ReceiveData();
		_delay_ms(10);
		if (receiveData == Button_PRESSESD){
			LED_voidON(DIO_U8PIN0);
			_delay_ms(100);
		}else if (receiveData == Button_RELEASED){
			LED_voidOFF(DIO_U8PIN0);
			_delay_ms(100);
		}
	}
}
