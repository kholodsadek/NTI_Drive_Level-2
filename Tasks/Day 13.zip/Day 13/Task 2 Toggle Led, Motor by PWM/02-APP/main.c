/*
 * main.c
 *
 *  Created on: Oct 22, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../01-LIB/BIT_MATH.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/05-TIMER0/TIMER0_Private.h"
#include "../04-MCAL/05-TIMER0/TIMER0_Interface.h"
#include "../04-MCAL/04-GIE/GIE_Interface.h"
#include "../03-HAL/06-DC_MOTOR/DC_Motor_Interface.h"

void ISR_vector_LED_25(void){ //duty 25%
	static u32 flag = 0;
	if (flag == 0){
		TCNT0 = 241;
		DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8LOW);
		flag = 1;
	}else if (flag == 1){
		TCNT0 = 251;
		DIO_voidSetPinValue(DIO_u8PORTA ,DIO_U8PIN0, DIO_u8HIGH);
		flag = 0;
	}
}

void ISR_vector_MOTOR_25(void){ //duty 25%
	Motor motor;
	motor.motor_port = DIO_u8PORTB;
	motor.motor_pin1 = DIO_U8PIN1;
	motor.motor_pin2 = DIO_U8PIN2;
	motor.motor_pin3 = DIO_U8PIN3;
	motor.motor_pin4 = DIO_U8PIN4;
	static u32 flag = 0;
	if (flag == 0){
		TCNT0 = 241;
		DCMotor_OFF(&motor);
		flag = 1;
	}else if (flag == 1){
		TCNT0 = 251;
		DCMotor_SetCW(&motor);
		flag = 0;
	}
}

void ISR_vector_MOTOR_50(void){ //duty 50%
	Motor motor;
	motor.motor_port = DIO_u8PORTB;
	motor.motor_pin1 = DIO_U8PIN1;
	motor.motor_pin2 = DIO_U8PIN2;
	motor.motor_pin3 = DIO_U8PIN3;
	motor.motor_pin4 = DIO_U8PIN4;
	static u32 flag = 0;
	flag++;
	if (flag == 246){
		DCMotor_SetCW(&motor);
		TCNT0 = 246;
		flag = 0;
	}
}


int main(void){
	TIMER0_init();
	/*LED*/
/*	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8OUTPUT);
	TIMER0_SetPreloadValue(241); //duty 20%
	DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8LOW);
	TIMER0_SetCallBackOv(ISR_vector_LED_25);
	GIE_EnableInterrupts();*/

	/*DC_MOTOR*/
	Motor motor;
	motor.motor_port = DIO_u8PORTB;
	motor.motor_pin1 = DIO_U8PIN1;
	motor.motor_pin2 = DIO_U8PIN2;
	motor.motor_pin3 = DIO_U8PIN3;
	motor.motor_pin4 = DIO_U8PIN4;
	DCMotor_init(&motor);

	TIMER0_SetPreloadValue(241);
	DCMotor_OFF(&motor);
	TIMER0_SetCallBackOv(ISR_vector_MOTOR_25); //duty 25%
//	TIMER0_SetCallBackOv(ISR_vector_MOTOR_50); //duty 50%

	GIE_EnableInterrupts();

	while(1){
	}
}
