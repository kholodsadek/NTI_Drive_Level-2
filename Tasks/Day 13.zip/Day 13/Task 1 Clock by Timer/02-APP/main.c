/*
 * main.c
 *
 *  Created on: Oct 22, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../03-HAL/04-CLCD/CLCD_Interface.h"
#include "../04-MCAL/04-GIE/GIE_Interface.h"
#include "../04-MCAL/05-TIMER0/TIMER0_Interface.h"
#include "../04-MCAL/05-TIMER0/TIMER0_Private.h"

void OverFlow_vector(void){
	static u32 counter = 0;
	static u32 hour = 0;
	static u32 min = 0;
	static u32 sec = 0;
	counter++;
	if (counter == 3906){
		sec++;
		if (sec == 60){
			CLCD_WriteString_Pos((u8*)"  ", 2, 10);
			sec = 0;
			min++;
		}
		if (min == 60){
			CLCD_WriteString_Pos((u8*)"  ", 2, 6);
			min = 0;
			hour++;
		}
		CLCD_WriteNum_Pos(hour, 2, 1);
		CLCD_WriteNum_Pos(min, 2, 6);
		CLCD_WriteNum_Pos(sec, 2, 10);
		counter = 0;
		TCNT0 = 192;
	}
}

int main(void){
	TIMER0_init();
	CLCD_init();
	TIMER0_SetCallBackOv(OverFlow_vector);
	TIMER0_SetPreloadValue(192); //TCNT0 = 192
	GIE_EnableInterrupts();

	CLCD_WriteString_Pos((u8*)"hour", 1, 1);
	CLCD_WriteString_Pos((u8*)"min", 1, 6);
	CLCD_WriteString_Pos((u8*)"sec", 1, 10);
	while(1){

	}
}
