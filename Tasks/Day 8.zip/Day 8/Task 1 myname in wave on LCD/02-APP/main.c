/*
 * main.c
 *
 *  Created on: Oct 6, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../03-HAL/04-CLCD/CLCD_Interface.h"
#include "util/delay.h"

int main(void){
	u8 myname[] = "kholod";
	CLCD_init();
	while(1){
		u8 row =1,col=1;
		while(col < 32){
			if (row == 1 || row == 2){
				CLCD_GoTo(row, col); //(1,1) (2,7) (1,13) (2,19)
				CLCD_WriteString(myname);
				_delay_ms(500);

				if(row == 2)
					row--; //1
				else if(row == 1)
					row++; //2 //2
			}
			col+=6;
		}
		_delay_ms(500);
		CLCD_DisplayClear();
	}
}
