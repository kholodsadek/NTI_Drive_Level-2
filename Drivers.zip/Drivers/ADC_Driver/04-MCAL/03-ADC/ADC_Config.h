/*
 * ADC_Config.h
 *
 *  Created on: Oct 20, 2023
 *      Author: hp
 */

#ifndef ADC_CONFIG_H_
#define ADC_CONFIG_H_

/* OPTIONS:
 * 1- DIV_BY_64
 * 2- DIV_BY_128    */
#define ADC_PRESC	 DIV_BY_128

#endif /* ADC_CONFIG_H_ */
