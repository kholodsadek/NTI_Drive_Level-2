/*
 * main.c
 *
 *  Created on: Oct 18, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/03-ADC/ADC_Interface.h"
#include "../03-HAL/04-CLCD/CLCD_Interface.h"
#include "../03-HAL/07-LM35/LM35_Interface.h"
#include "../03-HAL/08-POT/POT_Interface.h"
#include "../03-HAL/09-LDR/LDR_Interface.h"

int main(void){
//	u32 Local_u32Digital = 0;
//	u32 Local_u32Volt = 0.0;
////	u32 Local_u32MiliVolt = 0;
//	u32 Local_u32Temp = 0;
//
//	// ADC pin INPUT
//	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8INPUT);
//	//CLCD init
//	CLCD_init();
//	//LM35 init
//	LM35_init();
//	//POT init
//	POT_init();

	//CLCD words
//	u8 wordDigital[] = "Digital= ";
//	u8 wordVolt[]    =  "Volt= ";
//	u8 wordTemp[]    =  "Temp= ";

	DIO_voidSetPinDirection(DIO_u8PORTC, DIO_U8PIN0, DIO_u8OUTPUT);

	while(1){
		DIO_voidSetPinValue(DIO_u8PORTC, DIO_U8PIN0, DIO_u8HIGH);
//		Local_u32Digital = ADC_u8StartConversion(ADC_CHANNEL_A0);
//		Local_u32Volt    = (Local_u32Digital*5.0)/1023.0;
//		Local_u32MiliVolt     = (Local_u32Digital*5000)/1024;
//		Local_u32Temp = Local_u32MiliVolt/10;

//		Local_u32Temp = LM35_CallValue();
//		POT_CallValue(&Local_u32Digital, &Local_u32Volt);
//		Local_u32Digital = LDR_CallValue();
//
//		CLCD_WriteString_Pos(wordDigital, 1, 1);
//		CLCD_WriteNum(Local_u32Digital);
//		CLCD_WriteString_Pos(wordVolt, 2, 1);
//		CLCD_WriteNum(Local_u32Volt);
//		CLCD_WriteString_Pos(wordTemp, 1, 1);
//		CLCD_WriteNum(Local_u32Temp);

	}
}
