/*
 * main.c
 *
 *  Created on: Oct 6, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"
#include "../03-HAL/04-CLCD/CLCD_Interface.h"
#include "../03-HAL/05-KPD/KPD_Interface.h"
#include "util/delay.h"

int main(void){
	KPD_init();
	CLCD_init();
	/*while(1){
		u8 KeyPressed = KPD_GetPressedKey();
		DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN3, DIO_u8OUTPUT);
		if (KeyPressed == 0){
			DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN3, DIO_u8LOW);
			CLCD_WriteData('0');
			_delay_ms(200);
			CLCD_DisplayClear();
			_delay_ms(200);
		}
		else {
			DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN3, DIO_u8HIGH);
			CLCD_WriteData(KeyPressed);
			_delay_ms(1000);
			CLCD_DisplayClear();
			_delay_ms(200);
		}
	}*/
	u8 KeyPressed,num=0;
	while (KeyPressed != '='){
		KeyPressed = KPD_GetPressedKey(); //12
		if (KeyPressed == '=')
			break;
		if(KeyPressed != 0){
			CLCD_WriteData(KeyPressed);
			num += (KeyPressed- 48); // 12
			num *= 10; //120
		}
	}
	num /= 10; //12
	CLCD_WriteData(KeyPressed);
	CLCD_GoTo(2,1);
    CLCD_PrintBinary(num);
    CLCD_WriteChar(',');
    CLCD_printHEXNum(num);
	// (keypressed)char = '1', hex = 31, decimal =  49, bin = 0011 0001
	while(1){

	}
}
