/*
 * SPI_Config.h
 *
 *  Created on: Oct 27, 2023
 *      Author: hp
 */

#ifndef SPI_CONFIG_H_
#define SPI_CONFIG_H_

#define SLAVE_MODE   0
#define MASTER_MODE  1

#define SPI_MODE SLAVE_MODE

#endif /* SPI_CONFIG_H_ */
