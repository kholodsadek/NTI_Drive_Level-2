/*
 * main.c
 *
 *  Created on: Oct 27, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/06-SPI/SPI_Interface.h"
#include "util/delay.h"

int main(void){
	u8 receiveData;

	/* MISO OUTPUT */
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN4, DIO_u8INPUT); //spi ss
	DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN4, DIO_u8HIGH);
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN5, DIO_u8INPUT); //MOSI
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN7, DIO_u8INPUT); //SCK
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN6, DIO_u8OUTPUT); //MISO

	DIO_voidSetPinDirection(DIO_u8PORTD, DIO_U8PIN0, DIO_u8OUTPUT); //led
	DIO_voidSetPinDirection(DIO_u8PORTD, DIO_U8PIN1, DIO_u8OUTPUT); //led

	SPI_SlaveInit();

	while(1){
		//receiveData = SPI_ExcahngeData(88);
		receiveData = SPI_ReceiveData();
		_delay_ms(10);
		if (receiveData == 'K'){
			DIO_voidSetPinValue(DIO_u8PORTD, DIO_U8PIN0, DIO_u8HIGH);
		}
	}
}
