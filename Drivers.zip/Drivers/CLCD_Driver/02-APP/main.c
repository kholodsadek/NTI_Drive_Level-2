/*
 * main.c
 *
 *  Created on: Oct 6, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"
#include "../03-HAL/04-CLCD/CLCD_Interface.h"
#include "util/delay.h"

u8 arr_myname1[8] = {0x00,0x02,0x07,0x01,0x1F,0x00,0x00,0x00};
u8 arr_myname2[8] = {0x00,0x01,0x01,0x01,0x1F,0x00,0x00,0x00};
u8 arr_myname3[8] =	{0x00,0x00,0x0E,0x0A,0x0F,0x02,0x04,0x08};
u8 arr_myname4[8] =	{0x00,0x00,0x02,0x02,0x0E,0x00,0x00,0x00};

int main(void){
	CLCD_init();
	// Define custom characters at different CGRAM addresses
	CLCD_Draw_Char(0, arr_myname1);
	CLCD_Draw_Char(1, arr_myname2);
	CLCD_Draw_Char(2, arr_myname3);
	CLCD_Draw_Char(3, arr_myname4);

	// Use the custom characters at different positions
	for (u8 col = 15, i = 0; col > 11 && i < 4; col--, i++) {
		CLCD_WriteData_Pos(i,1,col);
//		CLCD_GoTo(1, col);
//		CLCD_WriteData(i); // Display the custom character by its address
		_delay_ms(500);
	}
	while(1){

	}
}
