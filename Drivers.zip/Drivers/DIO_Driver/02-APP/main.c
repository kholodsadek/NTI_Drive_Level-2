/*
 * main.c
 *
 *  Created on: Oct 5, 2023
 *      Author: hp
 */

#include "util/delay.h"
#include "../01-LIB/STD_TYPES.h"
#include "../01-LIB/BIT_MATH.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"
#include "../03-HAL/02-SEVEN_SEGMENT/SEVEN_SEGMENT_Interface.h"


int main(void){
	/*DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN3, DIO_u8OUTPUT);

	while(1){
		DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN3, DIO_u8HIGH);
		_delay_ms(500);
		DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN3, DIO_u8LOW);
		_delay_ms(500);
	}*/

	/*LED_voidInit();
	while(1){
		LED_voidON(DIO_U8PIN0);
		_delay_ms(500);
		LED_voidOFF(DIO_U8PIN0);
		_delay_ms(500);
	}*/

	SevenSegment_voidInit();
	while(1){
		SevenSegment_voidDispaly(9);
	}
}
