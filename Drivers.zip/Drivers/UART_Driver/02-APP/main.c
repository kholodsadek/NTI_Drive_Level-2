/*
 * main.c
 *
 *  Created on: Oct 27, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/07-UART/UART_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"

int main(void){

	USART_voidInit();
	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8OUTPUT);

	while(1){
		u8 val = USART_u8ReceiveData();
		if (val == 'A'){
			DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8HIGH);
		}else if (val == 'C'){
			DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8LOW);
		}
	}
}
