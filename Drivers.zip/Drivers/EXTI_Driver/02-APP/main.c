/*
 * main.c
 *
 *  Created on: Oct 18, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../03-HAL/06-DC_MOTOR/DC_Motor_Interface.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/02-EXTI/EXTI_Interface.h"
#include "../03-HAL/03-BUSH_BUTTON/BushButton_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"
#include "util/delay.h"

void myCallbackFunction(void) {
	LED_voidInit(DIO_U8PIN0);
	DIO_voidToggleValue(DIO_u8PORTA,DIO_U8PIN0);
	_delay_ms(1000);
}

int main(void){
	DIO_voidSetPinDirection(DIO_u8PORTD,DIO_U8PIN2,DIO_u8INPUT);
	DIO_voidSetPinValue(DIO_u8PORTD,DIO_U8PIN2,DIO_u8HIGH);
	EXTI_init();
	EXTI_SetCallBack(myCallbackFunction, 0);
	LED_voidInit(DIO_U8PIN1);

	while(1){
		LED_voidON(DIO_U8PIN1);
		_delay_ms(500);
		LED_voidOFF(DIO_U8PIN1);
		_delay_ms(500);
	}
}
