/*
 * main.c
 *
 *  Created on: Oct 29, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/08-WDT/WDT_Interface.h"
#include "util/delay.h"

int main(void){
	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8OUTPUT);

	WDT_Enable();
	DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8HIGH);
	_delay_ms(1500);
	DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8LOW);
	_delay_ms(1500);
	WDT_Disable();

	while(1);
}
