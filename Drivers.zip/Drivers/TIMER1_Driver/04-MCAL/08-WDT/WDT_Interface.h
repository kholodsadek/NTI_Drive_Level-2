/*
 * WDT_Interface.h
 *
 *  Created on: Oct 29, 2023
 *      Author: hp
 */

#ifndef WDT_INTERFACE_H_
#define WDT_INTERFACE_H_

void WDT_Enable(void);
void WDT_Disable(void);


#endif /* WDT_INTERFACE_H_ */
