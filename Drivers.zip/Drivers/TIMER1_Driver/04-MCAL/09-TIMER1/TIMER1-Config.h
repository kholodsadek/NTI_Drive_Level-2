/*
 * TIMER1-Config.h
 *
 *  Created on: Oct 29, 2023
 *      Author: hp
 */

#ifndef TIMER1_CONFIG_H_
#define TIMER1_CONFIG_H_



#endif /* TIMER1_CONFIG_H_ */
