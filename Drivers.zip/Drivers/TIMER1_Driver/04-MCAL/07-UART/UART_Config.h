/*
 * UART_Config.h
 *
 *  Created on: Oct 28, 2023
 *      Author: hp
 */

#ifndef UART_CONFIG_H_
#define UART_CONFIG_H_



#endif /* UART_CONFIG_H_ */
