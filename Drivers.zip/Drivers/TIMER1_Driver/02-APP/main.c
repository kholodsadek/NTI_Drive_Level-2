/*
 * main.c
 *
 *  Created on: Oct 29, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/03-ADC/ADC_Interface.h"
#include "../04-MCAL/09-TIMER1/TIMER1_Interface.h"
#include "util/delay.h"

int main(void){
	s32 prevVal = -1;
	ADC_voidInit();
	TIMER1_init();
	TIMER1_SetICR1Value(20000);
	DIO_voidSetPinDirection(DIO_u8PORTB, DIO_U8PIN3, DIO_u8OUTPUT);
	while(1){
		/* Digital reading of pot */
		s32 digital = ADC_u8StartConversion(ADC_CHANNEL_A0);
		if (digital > prevVal){
			DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN3, DIO_u8HIGH);
			TIMER1_SetOCR1BValue(1000);
			DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN3, DIO_u8LOW);
		}else {
			TIMER1_SetOCR1BValue(2000);
			DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN3, DIO_u8LOW);
			TIMER1_SetOCR1BValue(2000);
			DIO_voidSetPinValue(DIO_u8PORTB, DIO_U8PIN3, DIO_u8HIGH);
		}
		prevVal = digital;
		_delay_ms(1000);
	}
}
