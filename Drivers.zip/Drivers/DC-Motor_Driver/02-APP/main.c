/*
 * main.c
 *
 *  Created on: Oct 12, 2023
 *      Author: hp
 */


#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../03-HAL/06-DC_MOTOR/DC_Motor_Interface.h"

int main(void){
	Motor motor;
	motor.motor_port = DIO_u8PORTA;
	motor.motor_pin1 = DIO_U8PIN1;
	motor.motor_pin2 = DIO_U8PIN2;
	motor.motor_pin3 = DIO_U8PIN3;
	motor.motor_pin4 = DIO_U8PIN4;

	//MOTOR init
 	DCMotor_init(&motor);
	//SW init
	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8INPUT);
	DIO_voidSetPinValue(DIO_u8PORTA,DIO_U8PIN0,DIO_u8HIGH); //pull up

	while(1){
		u8 read = DIO_u8GetPinValue(DIO_u8PORTA, DIO_U8PIN0);
		if (read == 0){ //pressed //CCW
			DCMotor_SetCCW(&motor);
		}
		else if (read == 1){ //released //CW
			DCMotor_SetCW(&motor);
		}
	}
}
