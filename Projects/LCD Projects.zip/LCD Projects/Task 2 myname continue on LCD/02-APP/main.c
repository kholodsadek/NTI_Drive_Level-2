/*
 * main.c
 *
 *  Created on: Oct 6, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../03-HAL/04-CLCD/CLCD_Interface.h"
#include "util/delay.h"

u8 arr_myname1[8] = {0x00,0x02,0x07,0x01,0x1F,0x00,0x00,0x00};
u8 arr_myname2[8] = {0x00,0x01,0x01,0x01,0x1F,0x00,0x00,0x00};
u8 arr_myname3[8] =	{0x00,0x00,0x0E,0x0A,0x0F,0x02,0x04,0x08};
u8 arr_myname4[8] =	{0x00,0x00,0x02,0x02,0x0E,0x00,0x00,0x00};

int main(void){
	CLCD_init();
	//u8 myname[] = "kholod";
	CLCD_Draw_Char(0, arr_myname1);
	CLCD_Draw_Char(1, arr_myname2);
	CLCD_Draw_Char(2, arr_myname3);
	CLCD_Draw_Char(3, arr_myname4);

	while(1){
		u8 row=1,col=16,i=0;
		//in English
		/*while(col < 16){
			CLCD_GoTo(row, col); //(1,1) (1,2) (1,3) (1,4) (1,5) (1,6)
			CLCD_WriteChar(myname[i]); //k
			_delay_ms(200);
			col++; //2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 1
			i++;  //1 2 3 4 5 0 1 2 3 4 5 0 1 2 3 4 5 0 1 2
			if(col == 16 && row == 1){
				row ++;
				col = 1;
			}else if(col == 16 && row ==2){
				row--;
				col = 1;
			}
			if(i==6){
				i=0;
			}
		}*/
		//in Arabic
		while(col > 0){
			CLCD_GoTo(row, col); //(1,16) (1,15) (1,14)
			CLCD_WriteData(i);
			_delay_ms(200);
			col--;
			i++;  //1 2 3 4 5 0 1 2 3 4 5 0 1 2 3 4 5 0 1 2
			if(col == 0 && row == 1){
				row ++;
				col = 16;
			}else if(col == 0 && row ==2){
				row--;
				col = 16;
			}
			if(i==4){
				i=0;
			}
		}
	}
}
