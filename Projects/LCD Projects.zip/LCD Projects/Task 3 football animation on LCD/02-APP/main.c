/*
 * main.c
 *
 *  Created on: Oct 6, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../03-HAL/01-LED/LED_Interface.h"
#include "../03-HAL/04-CLCD/CLCD_Interface.h"
#include "../03-HAL/03-BUSH_BUTTON/BushButton_Interface.h"
#include "util/delay.h"

u8 boyChar[]   = {0x1F,0x11,0x11,0x1F,0x04,0x0E,0x04,0x0E};
u8 ballChar[]  = {0x00,0x00,0x00,0x0E,0x0A,0x0E,0x00,0x00};
u8 goalPlace[] = {0x00,0x00,0x07,0x01,0x01, 0x01,0x07,0x00};
u8 nullChar[]  = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};


int main(void){
	u8 wordGameName[] = "FOOT_BALL GAME";
	u8 wordGOAL[]  = "GOAL";
	u8 wordLOSER[] = "LOSER";
	u8 wordPush[]  = "PUSH_NOW";
	u8 wordButton1[]= "PUSHED_BUTTON1";
	u8 wordButton2[]= "PUSHED_BUTTON2";
	u8 wordEnd[] ="END GAME";
	Button myButton1;
	Button myButton2;
	myButton1.button_pin = DIO_U8PIN3;
	myButton1.button_port = DIO_u8PORTB;
	myButton2.button_port = DIO_u8PORTB;
	myButton2.button_pin = DIO_U8PIN4;

	CLCD_init();
	BushButton_voidInit(&myButton1);
	BushButton_voidInit(&myButton2);

	// Define custom characters at different CGRAM addresses
	CLCD_Draw_Char(0,nullChar);
	CLCD_Draw_Char(1,boyChar);
	CLCD_Draw_Char(2,ballChar);
	CLCD_Draw_Char(3,goalPlace);


	// Use the custom characters at different positions

	while(1){
		CLCD_GoTo(1,1);
		CLCD_WriteString(wordGameName);
		_delay_ms(1000);
		CLCD_DisplayClear();

		CLCD_GoTo(2,1);
		CLCD_WriteData(1); //display boy in location 1
		CLCD_GoTo(2,3);
		CLCD_WriteData(2); // display ball in location 3
		CLCD_GoTo(2,16);
		CLCD_WriteData(3); // display goal_place in location 16

		CLCD_GoTo(1,4);
		CLCD_WriteString(wordPush); // display push now

		u8 button1Press = BushButton_voidRead(&myButton1); //SW_1
		u8 button2Press = BushButton_voidRead(&myButton2); //SW_2
		_delay_ms(1000);

		if(button1Press == 0 && button2Press == 1){ // SW 1 make a goal
			CLCD_GoTo(1,4);  //clear word push now
			CLCD_WriteData(0);
			CLCD_GoTo(1,2);
			CLCD_WriteString(wordButton1);

			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(0); //clear boy from location 1
			_delay_ms(500);

			CLCD_GoTo(2,2);
			CLCD_WriteData(1); //display boy in location 2
			_delay_ms(500);
			CLCD_GoTo(2,2);
			CLCD_WriteData(0); //clear boy from location 2
			_delay_ms(500);

			CLCD_GoTo(2,3);
			CLCD_WriteData(1); //display boy in location 3 to push the ball

			CLCD_GoTo(2,15); //display the ball front of the goal place
			CLCD_WriteData(2);
			_delay_ms(1000);
			CLCD_DisplayClear();

			CLCD_GoTo(1,8);
			CLCD_WriteString(wordGOAL);
			CLCD_GoTo(2,1);
			CLCD_WriteData(1); //display boy in location 1
			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(0); //clear boy from location 1
			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(1); //display boy in location 1
			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(0); //clear boy from location 1
			_delay_ms(500);

			CLCD_DisplayClear();
			_delay_ms(500);
		}
		else if(button2Press == 0 && button1Press == 1){ //but SW 2 push the ball out
			CLCD_GoTo(1,4);  //clear word push now
			CLCD_WriteData(0);
			CLCD_GoTo(1,2);
			CLCD_WriteString(wordButton2);

			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(0); //clear boy from location 1
			_delay_ms(500);

			CLCD_GoTo(2,2);
			CLCD_WriteData(1); //display boy in location 2
			_delay_ms(500);
			CLCD_GoTo(2,2);
			CLCD_WriteData(0); //clear boy from location 2
			_delay_ms(500);

			CLCD_GoTo(2,3);
			CLCD_WriteData(1); //display boy in location 3 to push the ball

			CLCD_GoTo(1,16);  //display the ball out of the goal place
			CLCD_WriteData(2);
			_delay_ms(1000);
			CLCD_DisplayClear();

			CLCD_GoTo(1,8);
			CLCD_WriteString(wordLOSER);
			CLCD_GoTo(2,1);
			CLCD_WriteData(1); //display boy in location 1
			_delay_ms(2000);

			CLCD_DisplayClear();
			_delay_ms(500);
		}
		else if(button1Press == 1 && button2Press == 1){
			CLCD_GoTo(2,1);
			CLCD_WriteData(1); //display boy in location 1
			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(0); //clear boy from location 1
			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(1); //display boy in location 1
			_delay_ms(500);
			CLCD_GoTo(2,1);
			CLCD_WriteData(0); //clear boy from location 1
			_delay_ms(500);
		}
		CLCD_DisplayClear();
		CLCD_GoTo(1,1);
		CLCD_WriteString(wordEnd);
		_delay_ms(1000);
		CLCD_DisplayClear();
		_delay_ms(200);

	}
}
