/*
 * main.c
 *
 *  Created on: Oct 12, 2023
 *      Author: hp
 */


#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"

int main(void){
	DIO_voidSetPinDirection(DIO_u8PORTA,DIO_U8PIN0,DIO_u8INPUT);
	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN1, DIO_u8OUTPUT);
	DIO_voidSetPinValue(DIO_u8PORTA,DIO_U8PIN0,DIO_u8HIGH); //pull up
	u8 read = 5;
	while(1){
		read = DIO_u8GetPinValue(DIO_u8PORTA, DIO_U8PIN0);
		if (read == 0){ //pressed
			DIO_voidSetPinValue(DIO_u8PORTA,DIO_U8PIN1,DIO_u8HIGH);
		}
		else if (read == 1){ //released
			DIO_voidSetPinValue(DIO_u8PORTA,DIO_U8PIN1,DIO_u8LOW);
		}
	}
}
