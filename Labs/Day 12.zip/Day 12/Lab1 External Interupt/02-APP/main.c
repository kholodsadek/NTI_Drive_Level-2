/*
 * main.c
 *
 *  Created on: Oct 18, 2023
 *      Author: hp
 */
#include "../01-LIB/BIT_MATH.h"
#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/01-DIO/DIO_Private.h"
#include "util/delay.h"

#define MCUCR       *((volatile u8 *)0x55) //GIE INTERUPT1
#define MCUCUR      *((volatile u8 *)0x54) //GIE INTERUPT2
#define GICR        *((volatile u8 *)0x5B) //PIE
#define GIFR        *((volatile u8 *)0x5A) //PIF
#define SREG        *((volatile u8 *)0x5F) //GIE

//Calling by HW
void __vector_1  (void) __attribute__ ((signal));
void __vector_1  (void){
	_delay_ms(500);
	TOGGLE_BIT(PORTA,1); //D1 LED
}

int main(void){
	//SWITCH
	DIO_voidSetPinDirection(DIO_u8PORTD,DIO_U8PIN2,DIO_u8INPUT); //PD2 -> INPUT   (SW)
	DIO_voidSetPinValue(DIO_u8PORTD,DIO_U8PIN2,DIO_u8HIGH);      //PD2 -> pull up (SW)
	//LED
	DIO_voidSetPinDirection(DIO_u8PORTA,DIO_U8PIN0,DIO_u8OUTPUT); //A0 LED1 -> OUPTUT (LED)
	DIO_voidSetPinDirection(DIO_u8PORTA,DIO_U8PIN1,DIO_u8OUTPUT); //A1 LED2 -> OUPTUT (LED will toggle when interrupt is happened)

	//GIE -> ENABLE
	// SET INT0 --> falling
	SET_BIT(MCUCR, 1);
	CLR_BIT(MCUCR, 0);
	SET_BIT(GICR,  6); //PIE (INT0) -> ENABLE
	SET_BIT(SREG,  7); //GIE (INT0) -> ENABLE
	//Interrupt is ENABLED now
	//Flag is ready ->interrupt is occured

	while(1){
		DIO_voidSetPinValue(DIO_u8PORTA,DIO_U8PIN0,DIO_u8HIGH);
		_delay_ms(1000);
		DIO_voidSetPinValue(DIO_u8PORTA,DIO_U8PIN0,DIO_u8LOW);
		_delay_ms(1000);
	}
}
