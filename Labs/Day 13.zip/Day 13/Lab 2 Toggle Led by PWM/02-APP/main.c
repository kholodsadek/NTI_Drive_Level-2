/*
 * main.c
 *
 *  Created on: Oct 22, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../01-LIB/BIT_MATH.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/05-TIMER0/TIMER0_Private.h"
#include "../04-MCAL/05-TIMER0/TIMER0_Interface.h"
#include "../04-MCAL/04-GIE/GIE_Interface.h"
#include "util/delay.h"

void ISR_vector(void){ //20% Duty
	static u32 flag = 0;
	if (flag == 0){
		TCNT0 = 248;
		DIO_voidToggleValue(DIO_u8PORTA,DIO_U8PIN0);
		flag = 1;
	}else if (flag == 1){
		TCNT0 = 254;
		DIO_voidToggleValue(DIO_u8PORTA ,DIO_U8PIN0);
		flag = 0;
	}
}

void ISR1_vector(void){ //25% duty
	static u32 flag = 0;
	if (flag == 0){
		TCNT0 = 251;
		DIO_voidToggleValue(DIO_u8PORTA,DIO_U8PIN0);
		flag = 1;
	}else if (flag == 1){
		TCNT0 = 241;
		DIO_voidToggleValue(DIO_u8PORTA,DIO_U8PIN0);
		flag = 0;
	}
}

void ISR2_vector(void){ //50% duty
	static u32 flag = 0;
	flag++;
	if (flag == 246){
		DIO_voidToggleValue(DIO_u8PORTA, DIO_U8PIN0);
		TCNT0 = 246;
		flag = 0;
	}
}

int main(void){
	TIMER0_init();
	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8OUTPUT);

	TIMER0_SetPreloadValue(254);
	DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8LOW);
	TIMER0_SetCallBackOv(ISR_vector);
	GIE_EnableInterrupts();

//	TIMER0_SetPreloadValue(241);
//	DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8LOW);
//	TIMER0_SetCallBackOv(ISR1_vector);
//	GIE_EnableInterrupts();

//	TIMER0_SetPreloadValue(246);
//	DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN0, DIO_u8LOW);
//	TIMER0_SetCallBackOv(ISR2_vector);
//	GIE_EnableInterrupts();

//	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN7, DIO_u8OUTPUT);
	while(1){
/*		DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN7, DIO_u8LOW);
		_delay_ms(1000);
		DIO_voidSetPinValue(DIO_u8PORTA, DIO_U8PIN7, DIO_u8HIGH);
		_delay_ms(1000);*/
	}
}
