/*
 * main.c
 *
 *  Created on: Oct 22, 2023
 *      Author: hp
 */

#include "../01-LIB/STD_TYPES.h"
#include "../04-MCAL/01-DIO/DIO_Interface.h"
#include "../04-MCAL/02-EXTI/EXTI_Interface.h"
#include "util/delay.h"

#define TCCR0   *((volatile u8 *)0x53)
#define TCNT0   *((volatile u8 *)0x52)
#define TIMSX   *((volatile u8 *)0x59)
#define TIFR    *((volatile u8 *)0x58)
#define OCR0    *((volatile u8 *)0x5C)

void __vector_11(void)__attribute__((signal));
void __vector_11(void){
	static u32 counter = 0;
	counter++;
	if (counter == 3906){
		DIO_voidToggleValue(DIO_u8PORTA, DIO_U8PIN0);
		counter = 0;
		TCNT0  = 192;
	}
}//OVERFOLW Vector table

void __vector_10(void)__attribute__((signal));
void __vector_10(void){
	static u32 counter = 0;
	counter++;
	if (counter == 999){
		DIO_voidToggleValue(DIO_u8PORTA, DIO_U8PIN0);
		counter = 0;
	}
}//CTC Vector Table

int main(void){
	//LED -----> Toggle
    //CTC_MODE
	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8OUTPUT);
	//Set MODE ---> normal mode
	TCCR0 = 0b00001011; //64 (From prescaler)
	OCR0 = 125; //<--- value of X
	SET_BIT(TIMSX,1); //Output Compare Match Interrupt Enable
	EXTI_init();

	//OVERFOLW_MODE
/*	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN0, DIO_u8OUTPUT);
	TCCR0 = 0b00000010; //normal mode
	TCNT0 = 192; //init value
	SET_BIT(TIMSX,0); //Enable
	EXTI_init();*/

	DIO_voidSetPinDirection(DIO_u8PORTA, DIO_U8PIN7, DIO_u8OUTPUT);
	while(1){
		DIO_voidSetPinValue(DIO_u8PORTA , DIO_U8PIN7, DIO_u8LOW);
		_delay_ms(1000);
		DIO_voidSetPinValue(DIO_u8PORTA , DIO_U8PIN7, DIO_u8HIGH);
		_delay_ms(1000);
	}
}
